<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SellerResetPasswordMail extends Mailable
{
    use Queueable, SerializesModels;

    public $token;
    public $email;
    public $name;

    public function __construct($token, $email = null, $name = null)
    {
        $this->token = $token;
        $this->email = $email;
        $this->name = $name;
    }

    public function build()
    {
        return $this->subject('Reset your Shipxpeed password')
                    ->view('email.seller_reset_password')
                    ->with([
                        'resetUrl' => route('seller.reset.password.form', ['token' => $this->token, 'email' => $this->email]),
                    ]);
    }
}

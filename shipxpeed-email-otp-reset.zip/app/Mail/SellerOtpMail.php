<?php 

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SellerOtpMail extends Mailable
{
    use Queueable, SerializesModels;

    public $otp;
    public $name;
    public $validMinutes;

    public function __construct($otp, $name = null, $validMinutes = 10)
    {
        $this->otp = $otp;
        $this->name = $name;
        $this->validMinutes = $validMinutes;
    }

    public function build()
    {
        return $this->subject($this->otp . ' is your Shipxpeed verification code')
                    ->view('email.seller_otp');
    }
}

<?php

namespace App\Http\Controllers\Frontend;

use App\Helper\Helper;
use App\Mail\SellerResetPasswordMail;
use App\Mail\WelcomeMail;
use App\Models\SellerList;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use App\Mail\SellerOtpMail;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\SellerBankDetail;

class SellerAuthController extends Controller
{
    const OTP_VALID_MINUTES  = 10;  // OTP expires after 10 minutes
    const OTP_MAX_ATTEMPTS   = 5;   // wrong tries allowed per OTP
    const OTP_RESEND_SECONDS = 60;  // wait before "Resend OTP"
    const OTP_MAX_RESENDS    = 5;   // resends per registration


    public function showForgotPasswordForm()
    {
        return view('frontend.selleruser.forgot_password');
    }

    // Step 2: Handle sending Reset Link
    public function sendResetLinkEmail(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $email = strtolower(trim($request->email));
        $genericMsg = 'If this email is registered with us, a password reset link has been sent. Please check your inbox (and spam folder).';

        $seller = SellerList::whereRaw('LOWER(email) = ?', [$email])->first();
        if (!$seller) {
            // Do not reveal whether an account exists
            return back()->with('success', $genericMsg);
        }

        // Cooldown: one reset email per 60 seconds
        $existing = DB::table('password_resets')->where('email', $seller->email)->first();
        if ($existing && $existing->created_at && Carbon::parse($existing->created_at)->gt(now()->subSeconds(60))) {
            return back()->with('error', 'A reset link was just sent. Please wait a minute before trying again.');
        }

        $token = Str::random(64);

        DB::table('password_resets')->where('email', $seller->email)->delete();
        DB::table('password_resets')->insert([
            'email'      => $seller->email,
            'token'      => Hash::make($token), // store only a hash of the token
            'guard'      => 'seller',
            'created_at' => now(),
        ]);

        try {
            Mail::to($seller->email)->send(new SellerResetPasswordMail($token, $seller->email, $seller->name));
        } catch (\Throwable $e) {
            \Log::error('Reset mail failed: ' . $e->getMessage());
            DB::table('password_resets')->where('email', $seller->email)->delete();
            return back()->with('error', 'We could not send the email right now. Please try again in a few minutes.');
        }

        return back()->with('success', $genericMsg);
    }

    public function showResetPasswordForm(Request $request, $token)
    {
        return view('frontend.selleruser.reset_password', [
            'token' => $token,
            'email' => $request->query('email'),
        ]);
    }

    public function resetPassword(Request $request)
    {
        $request->validate([
            'email'    => 'required|email',
            'password' => 'required|confirmed|min:8',
            'token'    => 'required',
        ]);

        $seller = SellerList::whereRaw('LOWER(email) = ?', [strtolower(trim($request->email))])->first();
        $resetData = $seller ? DB::table('password_resets')->where('email', $seller->email)->first() : null;

        if (!$resetData || !Hash::check($request->token, $resetData->token)) {
            return back()->withInput($request->only('email'))->with('error', 'This reset link is invalid. Please request a new one.');
        }

        if (!$resetData->created_at || Carbon::parse($resetData->created_at)->lt(now()->subMinutes(60))) {
            DB::table('password_resets')->where('email', $seller->email)->delete();
            return redirect()->route('seller.password.request')->with('error', 'This reset link has expired. Please request a new one.');
        }

        $seller->password = Hash::make($request->password);
        $seller->save();

        DB::table('password_resets')->where('email', $seller->email)->delete();

        return redirect()->route('seller.login')->with('success', 'Your password has been reset successfully! Please log in.');
    }

    public function sellerregister(Request $request)
    {
        return view('frontend.selleruser.register');
    }

    public function showLoginForm()
    {
        return view('frontend.selleruser.login');
    }


    public function sellerstore(Request $request)
    {
        // dd($request->all());
        $validator = Validator::make($request->all(), [
            'user_type'         => 'required',
            'name'              => 'required',
            'email'             => 'required|email|unique:seller_lists,email',
            'phone_number'      => 'required',
            'password'          => 'required',
            'pan_card'          => 'nullable',
            'adhar_card_front'  => 'nullable',
            'adhar_card_back'   => 'nullable',
            'gst_no'            => 'nullable',
            'gst_photo'         => 'nullable',
            'cancel_cheque'     => 'nullable',
        ]);
// dd($validator->errors());
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
// echo 'scscs';die;

        $panCardPath      = $request->hasFile('pan_card')         ? Helper::saveFile($request->file('pan_card'), 'seller') : null;
        $adharFrontPath   = $request->hasFile('adhar_card_front') ? Helper::saveFile($request->file('adhar_card_front'), 'seller') : null;
        $adharBackPath    = $request->hasFile('adhar_card_back')  ? Helper::saveFile($request->file('adhar_card_back'), 'seller') : null;
        $gstPhotoPath     = $request->hasFile('gst_photo')        ? Helper::saveFile($request->file('gst_photo'), 'seller') : null;
        $cancelChequePath = $request->hasFile('cancel_cheque')    ? Helper::saveFile($request->file('cancel_cheque'), 'seller') : null;

        $otp = random_int(100000, 999999);


        Session::put('seller_temp_data', [
            'user_type'         => $request->user_type,
            'name'              => $request->name,
            'email'             => $request->email,
            'phone_number'      => $request->phone_number,
            'password'          => Hash::make($request->password),
            'pan_card'          => $panCardPath,
            'adhar_card_front'  => $adharFrontPath,
            'adhar_card_back'   => $adharBackPath,
            'gst_no'            => $request->gst_no,
            'gst_photo'         => $gstPhotoPath,
            'cancel_cheque'     => $cancelChequePath,
            'otp'               => Hash::make((string) $otp),
            'otp_expires_at'    => now()->addMinutes(self::OTP_VALID_MINUTES)->timestamp,
            'otp_attempts'      => 0,
            'otp_sent_at'       => now()->timestamp,
            'otp_resends'       => 0,
        ]);

        try {
            Mail::to($request->email)->send(new SellerOtpMail($otp, $request->name, self::OTP_VALID_MINUTES));
        } catch (\Throwable $e) {
            \Log::error('OTP mail failed: ' . $e->getMessage());
            Session::forget('seller_temp_data');
            return response()->json([
                'message' => 'We could not send the OTP email right now. Please try again in a few minutes.',
            ], 500);
        }
        return response()->json([
            'message' => 'OTP sent to your email. Please verify to complete registration.',
            'redirect_url' => route('seller.verify.otp.view')
        ]);
    }
    public function resendOtp(Request $request)
    {
        $data = Session::get('seller_temp_data');
        if (!$data) {
            return redirect()->route('register.get')->with('error', 'Session expired. Please register again.');
        }

        $wait = ($data['otp_sent_at'] ?? 0) + self::OTP_RESEND_SECONDS - now()->timestamp;
        if ($wait > 0) {
            return redirect()->route('seller.verify.otp.view')->with('error', "Please wait {$wait} seconds before requesting a new OTP.");
        }
        if (($data['otp_resends'] ?? 0) >= self::OTP_MAX_RESENDS) {
            Session::forget('seller_temp_data');
            return redirect()->route('register.get')->with('error', 'Too many OTP requests. Please register again.');
        }

        $otp = random_int(100000, 999999);
        $data['otp']            = Hash::make((string) $otp);
        $data['otp_expires_at'] = now()->addMinutes(self::OTP_VALID_MINUTES)->timestamp;
        $data['otp_attempts']   = 0;
        $data['otp_sent_at']    = now()->timestamp;
        $data['otp_resends']    = ($data['otp_resends'] ?? 0) + 1;

        try {
            Mail::to($data['email'])->send(new SellerOtpMail($otp, $data['name'] ?? null, self::OTP_VALID_MINUTES));
        } catch (\Throwable $e) {
            \Log::error('OTP resend failed: ' . $e->getMessage());
            return redirect()->route('seller.verify.otp.view')->with('error', 'We could not send the OTP email. Please try again shortly.');
        }

        Session::put('seller_temp_data', $data);

        return redirect()->route('seller.verify.otp.view')->with('success', 'A new OTP has been sent to your email.');
    }

    public function showVerifyOtpForm()
    {
        $data = Session::get('seller_temp_data');
        if (!$data) {
            return redirect()->route('register.get')->with('error', 'Session expired. Please register again.');
        }

        return view('email.verify_otp', [
            'maskedEmail'  => self::maskEmail($data['email']),
            'resendIn'     => max(0, ($data['otp_sent_at'] ?? 0) + self::OTP_RESEND_SECONDS - now()->timestamp),
            'validMinutes' => self::OTP_VALID_MINUTES,
        ]);
    }

    private static function maskEmail($email)
    {
        [$user, $domain] = array_pad(explode('@', $email, 2), 2, '');
        $visible = mb_substr($user, 0, min(2, mb_strlen($user)));
        return $visible . str_repeat('*', max(1, mb_strlen($user) - 2)) . '@' . $domain;
    }

    public function verifyOtp(Request $request)
    {
        $request->validate(['otp' => 'required|digits:6']);

        $sessionData = Session::get('seller_temp_data');

        if (!$sessionData) {
            return redirect()->route('register.get')->with('error', 'Session expired. Please register again.');
        }

        if (now()->timestamp > ($sessionData['otp_expires_at'] ?? 0)) {
            return redirect()->route('seller.verify.otp.view')->with('error', 'This OTP has expired. Please click "Resend OTP" to get a new one.');
        }

        if (($sessionData['otp_attempts'] ?? 0) >= self::OTP_MAX_ATTEMPTS) {
            return redirect()->route('seller.verify.otp.view')->with('error', 'Too many wrong attempts. Please click "Resend OTP" to get a new one.');
        }

        if (!Hash::check((string) $request->otp, $sessionData['otp'])) {
            $sessionData['otp_attempts'] = ($sessionData['otp_attempts'] ?? 0) + 1;
            Session::put('seller_temp_data', $sessionData);
            $left = self::OTP_MAX_ATTEMPTS - $sessionData['otp_attempts'];
            return redirect()->route('seller.verify.otp.view')->with('error', "Invalid OTP. {$left} attempt(s) left.");
        }

        // Email may have been registered meanwhile (e.g. second tab)
        if (SellerList::where('email', $sessionData['email'])->exists()) {
            Session::forget('seller_temp_data');
            return redirect()->route('seller.login')->with('error', 'This email is already registered. Please log in.');
        }

        // Save seller data
        $seller = new SellerList();
        $seller->user_type         = $sessionData['user_type'];
        $seller->name              = $sessionData['name'];
        $seller->email             = $sessionData['email'];
        $seller->phone_number      = $sessionData['phone_number'];
        $seller->password          = $sessionData['password'];
        $seller->pan_card          = $sessionData['pan_card'];
        $seller->adhar_card_front  = $sessionData['adhar_card_front'];
        $seller->adhar_card_back   = $sessionData['adhar_card_back'];
        $seller->gst_no            = $sessionData['gst_no'];
        $seller->gst_photo         = $sessionData['gst_photo'];
        $seller->cancel_cheque     = $sessionData['cancel_cheque'];
        $seller->status            = 0;
        $seller->kyc_status        = 0;
        $seller->save();

        Session::forget('seller_temp_data');


        $site_settings = [
            'application_name' => 'Shipxpeed',
            'logo' => 'path/to/logo.png',
        ];

        // Send Welcome Email
        try {
            Mail::to($seller->email)->send(new WelcomeMail($seller->name, $site_settings));
        } catch (\Throwable $e) {
            \Log::error('Welcome mail failed: ' . $e->getMessage());
        }

        return redirect()->route('seller.login')->with('success', 'Registration completed successfully!');
    }



    public function completeKyc(Request $request)
{
    // dd($request);
    $validator = Validator::make($request->all(), [
        'bank_name'             => 'required',
        'bank_account_verified' => 'required',
        'gst_verified_name'     => 'nullable',
        'pan_verified_name'     => 'required',
        'account_number'        => 'required',
        'ifsc_code'             => 'required',
        'gst_number'            => 'nullable',
        'pan_number'            => 'required',
    ]);

    if ($validator->fails()) {
        return redirect()->back()
            ->withErrors($validator)
            ->withInput()
            ->with('error', 'Please correct the errors in the form.');
    }

    try {
        $authSeller = Auth::guard('seller')->user();

        if (!$authSeller) {
            return redirect()->back()->with('error', 'Unauthorized or seller not found.');
        }

        $seller = SellerList::find($authSeller->id);

        if (!$seller) {
            return redirect()->back()->with('error', 'Seller not found in database.');
        }

        // Optional: Check if bank details already exist to prevent duplicate entry
        SellerBankDetail::updateOrCreate(
            ['seller_id' => $seller->id], // assumes there's a seller_id column
            [
                'account_number'      => $request->account_number,
                'account_holder_name' => $request->bank_name,
                'ifsc_code'           => $request->ifsc_code,
            ]
        );

        $seller->update([
            'bank_account_verified' => $request->bank_account_verified,
            'gst_verified_name'     => $request->gst_verified_name,
            'pan_verified_name'     => $request->pan_verified_name,
            'account_number'        => $request->account_number,
            'ifsc_code'             => $request->ifsc_code,
            'bank_name'             => $request->bank_name,
            'pan_number'            => $request->pan_number,
            'gst_no'                => $request->gst_number,
            'status'                => 1,
            'kyc_status'            => 1,
        ]);

        return redirect()->back()->with('success', 'KYC completed successfully.');
    } catch (\Exception $e) {
        // dd($e->getMessage());
        \Log::error('KYC Error: ' . $e->getMessage());

        return redirect()->back()
            ->with('error', 'Something went wrong while completing KYC.');
    }
}





// public function completeKyc(Request $request)
// {
//     $validator = Validator::make($request->all(), [
//         'bank_name'             => 'required',
//         'bank_account_verified' => 'required',
//         'gst_verified_name'     => 'nullable',
//         'pan_verified_name'     => 'required',
//         'account_number'        => 'required',
//         'ifsc_code'             => 'required',
//         'gst_number'            => 'nullable',
//         'pan_number'            => 'required',
//     ]);

//     if ($validator->fails()) {
//         return redirect()->back()
//             ->withErrors($validator)
//             ->withInput()
//             ->with('error', 'Please correct the errors in the form.');
//     }

//     try {
//         $seller = Auth::guard('seller')->user();

//         if (!$seller) {
//             return redirect()->back()->with('error', 'Unauthorized or seller not found.');
//         }

//         $seller = SellerList::find($seller->id);

//         if (!$seller) {
//             return redirect()->back()->with('error', 'Seller not found in database.');
//         }


    

//         $seller->bank_account_verified = $request->bank_account_verified;
//         $seller->gst_verified_name     = $request->gst_verified_name;
//         $seller->pan_verified_name     = $request->pan_verified_name;
//         $seller->account_number        = $request->account_number;
//         $seller->ifsc_code             = $request->ifsc_code;
//         $seller->bank_name             = $request->bank_name;
//         $seller->pan_number                = $request->pan_number;
//         $seller->gst_no                = $request->gst_number;
//         $seller->status            = 1;
//         $seller->kyc_status            = 1;
//         $seller->save();

//         return redirect()->back()->with('success', 'KYC completed successfully.');
//     } catch (\Exception $e) {
//         // . $e->getMessage()
//         return redirect()->back()
//             ->with('error', 'Something went wrong: ' );
//     }
// }



//     public function completeKyc(Request $request)
//     {
//         // dd($request);
//         $validator = Validator::make($request->all(), [
//             'bank_name'         => 'required',
//             'bank_account_verified'          => 'required',
//             'gst_verified_name'  => 'nullable',
//             'pan_verified_name'   => 'required',
//             'account_number'            =>'required',
//             'ifsc_code'         => 'required',
//             'gst_number'     => 'nullable',
//             'pan_number'            => 'required',
         

//         ]);

//          if ($validator->fails()) {
//         return redirect()->back()
//             ->withErrors($validator)
//             ->withInput()
//             ->with('error', 'Please correct the errors in the form.');
//          }
// try {
//         $seller = Auth::guard('seller')->user();

//         if (!$seller) {
//             return redirect()->back()->with('error', 'Unauthorized or seller not found.');
//         }

//         $sellerId = Auth::guard('seller')->id();
//         $seller = SellerList::find($request->sellerId);

//         $seller->bank_account_verified = $request->bank_account_verified;
//         $seller->gst_verified_name = $request->gst_verified_name;
//         $seller->pan_verified_name = $request->pan_verified_name;
//         $seller->account_number = $request->account_number;
//         $seller->ifsc_code      = $request->ifsc_code;
//         $seller->bank_name      = $request->bank_name;
//         $seller->pan_no         = $request->pan_number;
//         $seller->kyc_status     = 1; // Mark KYC as complete
//         $seller->gst_no = $request->gst_number;
//         $seller->kyc_status = 1; // Mark KYC as complete
//         $seller->save();


//              return redirect()->back()->with('success', 'KYC completed successfully.');
//     } catch (\Exception $e) {
//         return redirect()->back()
//             ->with('error', 'Something went wrong: ' . $e->getMessage());
//     }

//     }



    // public function completeKyc(Request $request)
    // {
    //     $validator = Validator::make($request->all(), [
    //         'seller_id'         => 'required|exists:seller_lists,id',
    //         'pan_card'          => 'nullable|file',
    //         'adhar_card_front'  => 'nullable|file',
    //         'adhar_card_back'   => 'nullable|file',
    //         'gst_no'            => 'nullable|string',
    //         'gst_photo'         => 'nullable|file',
    //         'cancel_cheque'     => 'nullable|file',



    //         'kyc_type'            => 'nullable',
    //         'ie_Code'            => 'nullable',
    //         'ie_photo'            => 'nullable',
    //         'ad_Code'            => 'nullable',
    //         'ad_photo'            => 'nullable',

    //     ]);

    //     if ($validator->fails()) {
    //         return response()->json(['errors' => $validator->errors()], 422);
    //     }

    //     $seller = SellerList::find($request->seller_id);


        
    //     if ($request->hasFile('ie_photo')) {
    //         $seller->ie_photo = Helper::saveFile($request->file('ie_photo'), 'seller');
    //     }
        
    //     if ($request->hasFile('ad_photo')) {
    //         $seller->ad_photo = Helper::saveFile($request->file('ad_photo'), 'seller');
    //     }


    //     if ($request->hasFile('pan_card')) {
    //         $seller->pan_card = Helper::saveFile($request->file('pan_card'), 'seller');
    //     }
    //     if ($request->hasFile('adhar_card_front')) {
    //         $seller->adhar_card_front = Helper::saveFile($request->file('adhar_card_front'), 'seller');
    //     }
    //     if ($request->hasFile('adhar_card_back')) {
    //         $seller->adhar_card_back = Helper::saveFile($request->file('adhar_card_back'), 'seller');
    //     }
    //     if ($request->hasFile('gst_photo')) {
    //         $seller->gst_photo = Helper::saveFile($request->file('gst_photo'), 'seller');
    //     }
    //     if ($request->hasFile('cancel_cheque')) {
    //         $seller->cancel_cheque = Helper::saveFile($request->file('cancel_cheque'), 'seller');
    //     }

    //     $seller->gst_no = $request->gst_no;
    //     $seller->kyc_status = 1; // Mark KYC as complete
    //     $seller->save();

    //     return response()->json([
    //         'message' => 'KYC completed successfully.',
    //     ]);
    // }





    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if (Auth::guard('seller')->attempt($credentials)) {
            $request->session()->regenerate();


            if ($request->ajax()) {
                return response()->json(['redirect' => route('seller.dashboard')]);
            }

            return redirect()->route('seller.dashboard');
        }


        if ($request->ajax()) {
            return response()->json([
                'message' => 'Invalid email or password.'
            ], 401);
        }

        return back()->with('error', 'Invalid email or password');
    }

    public function logout(Request $request)
    {
        Auth::guard('seller')->logout(); // or Auth::logout() if you're not using guards
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->back();
    }





// public function sendOtp(Request $request)
// {
//     $request->validate([
//         'email' => 'required|email|unique:users,email',
//     ]);

//     $otp = rand(100000, 999999);
//     session([
//         'otp' => $otp,
//         'registration_data' => $request->all()
//     ]);

//     Mail::to($request->email)->send(new SignupOtpMail($otp));

//     return response()->json(['message' => 'OTP sent to your email.']);
// }




// public function verifyOtp(Request $request)
// {
//     if ($request->otp == session('otp')) {
//         $data = session('registration_data');
//         $user = User::create([
//             'name' => $data['name'],
//             'email' => $data['email'],
//             'phone_number' => $data['phone_number'],
//             'user_type' => $data['user_type'],
//             'password' => bcrypt($data['password']),
//         ]);

//         // Optionally send welcome mail
//         Mail::to($user->email)->send(new WelcomeMail($user));

//         session()->forget(['otp', 'registration_data']);

//         return response()->json(['message' => 'Registration successful!']);
//     }

//     return response()->json(['error' => 'Invalid OTP.'], 422);
// }


}

#!/usr/bin/env python3
"""Apply the Aadhaar-agreement + KYC update to the live panel. Backs up every file it touches."""
import os, re, shutil, sys, time

ROOT = '/var/www/shipxpeed'
HERE = os.path.dirname(os.path.abspath(__file__))
BK = '/root/kyc-backup-' + time.strftime('%Y%m%d-%H%M%S')
report = []


def path(p):
    return os.path.join(ROOT, p)


def backup(p):
    full = path(p)
    if os.path.exists(full):
        dst = os.path.join(BK, p)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(full, dst)


def read(p):
    with open(path(p), encoding='utf-8') as f:
        return f.read()


def write(p, s):
    backup(p)
    os.makedirs(os.path.dirname(path(p)), exist_ok=True)
    with open(path(p), 'w', encoding='utf-8') as f:
        f.write(s)
    report.append('updated ' + p)


def fail(msg):
    print('PATCH FAILED: ' + msg)
    sys.exit(1)


changes = {}

# ---------- 1. new / replaced files ----------
for rel in ['app/Services/CashfreeKyc.php',
            'app/Http/Controllers/selleradmin/CashfreeController.php',
            'config/cashfree_kyc.php',
            'resources/views/sellerdashboard/partials/agreement-sign.blade.php',
            'resources/views/sellerdashboard/partials/kyc.blade.php']:
    with open(os.path.join(HERE, 'files', rel), encoding='utf-8') as f:
        changes[rel] = f.read()

ACCEPT = open(os.path.join(HERE, 'acceptAgreement.php'), encoding='utf-8').read().rstrip('\n')
KYC = open(os.path.join(HERE, 'completeKyc.php'), encoding='utf-8').read().rstrip('\n')

# ---------- 2. Dashboard.php :: acceptAgreement ----------
p = 'app/Http/Controllers/selleradmin/Dashboard.php'
L = read(p).split('\n')
s0 = next((i for i, l in enumerate(L) if re.search(r'public function acceptAgreement\(', l)), None)
if s0 is None:
    fail('acceptAgreement not found')
depth, started, e = 0, False, None
for i in range(s0, len(L)):
    depth += L[i].count('{') - L[i].count('}')
    if '{' in L[i]:
        started = True
    if started and depth == 0:
        e = i
        break
if e is None:
    fail('acceptAgreement end not found')
L[s0:e + 1] = ACCEPT.split('\n')
changes[p] = '\n'.join(L)

# ---------- 3. SellerAuthController :: completeKyc ----------
p = 'app/Http/Controllers/Frontend/SellerAuthController.php'
L = read(p).split('\n')
s0 = next((i for i, l in enumerate(L) if re.match(r'\s*public function completeKyc\(', l)), None)
if s0 is None:
    fail('completeKyc not found')
depth, started, e = 0, False, None
for i in range(s0, len(L)):
    depth += L[i].count('{') - L[i].count('}')
    if '{' in L[i]:
        started = True
    if started and depth == 0:
        e = i
        break
L[s0:e + 1] = KYC.split('\n')
changes[p] = '\n'.join(L)

# ---------- 4. routes/web.php ----------
p = 'routes/web.php'
s = read(p)
if 'seller.digilocker.start' not in s:
    m = re.search(r"^.*Route::post\('/bank-verify'.*$", s, re.M)
    if not m:
        fail('bank-verify route not found')
    s = s[:m.end()] + """

// Seller onboarding: Aadhaar (DigiLocker) e-sign for the Client Service Agreement
Route::post('/seller/kyc/digilocker/start', [CashfreeController::class, 'digilockerStart'])->middleware('auth:seller')->name('seller.digilocker.start');
Route::get('/seller/kyc/digilocker/status', [CashfreeController::class, 'digilockerStatus'])->middleware('auth:seller')->name('seller.digilocker.status');
Route::get('/seller/kyc/digilocker/return', [CashfreeController::class, 'digilockerReturn'])->name('seller.digilocker.return');""" + s[m.end():]
    if 'use App\\Http\\Controllers\\selleradmin\\CashfreeController;' not in s:
        fail('CashfreeController import missing in routes')
    changes[p] = s

# ---------- 5. agreement PDF signature block ----------
p = 'resources/views/seller/agreement-pdf.blade.php'
s = read(p)
if '$signature' not in s:
    block = """
    @isset($signature)
    <div style="margin-top: 25px; border: 1px solid #2e7d32; padding: 10px; font-size: 11px;">
        <p style="margin:0 0 6px 0;"><strong>ELECTRONICALLY SIGNED BY CLIENT USING AADHAAR</strong></p>
        <p style="margin:0;">Signed by: <strong>{{ $signature['name'] }}</strong> &nbsp;|&nbsp; Aadhaar: {{ $signature['uid_masked'] }} &nbsp;|&nbsp; DOB: {{ $signature['dob'] }}</p>
        <p style="margin:0;">Address: {{ $clientAddress }}</p>
        <p style="margin:0;">Method: {{ $signature['method'] }} &nbsp;|&nbsp; Verification ID: {{ $signature['verification_id'] }} &nbsp;|&nbsp; Ref: {{ $signature['reference_id'] }}</p>
        <p style="margin:0;">Signed at: {{ $signature['signed_at'] }} &nbsp;|&nbsp; IP: {{ $signature['ip'] }}</p>
    </div>
    @endisset
"""
    if s.count('</body>') != 1:
        fail('agreement pdf </body> not found')
    s = s.replace('</body>', block + '</body>')
    changes[p] = s

# ---------- 6. dashboard.blade.php ----------
p = 'resources/views/sellerdashboard/dashboard.blade.php'
L = read(p).split('\n')
idx = lambda pat, start=0: next((i for i in range(start, len(L)) if re.search(pat, L[i])), None)

agr = idx(r'@if \(\$seller->agreement_accepted == 0\)')
kyc = idx(r'^\s*@if \(\$seller->kyc_status == 0\)\s*$')
if agr is None or kyc is None or kyc > agr:
    fail('kyc/agreement blocks not found (%s, %s)' % (kyc, agr))

# 6a. agreement modal: replace the Aadhaar OTP form + footer with the new sign partial
form = idx(r'<form id="agreementForm"', agr)
foot = idx(r'class="modal-footer"', form or 0)
if form is None or foot is None:
    fail('agreement form/footer not found')
if not re.search(r'</div>', L[foot + 2]) or not re.search(r'</div>', L[foot - 1]):
    fail('unexpected agreement footer layout: ' + L[foot - 1] + ' / ' + L[foot + 2])
L[form:foot + 3] = ["                @include('sellerdashboard.partials.agreement-sign')", "            </div>"]

# 6b. agreement modal cannot be closed until signed
close = idx(r'btn-close', agr)
if close is not None and close < form:
    L[close] = ''

# 6c. remove old auto-show + Aadhaar OTP scripts
auto = idx(r'JavaScript to show Agreement Modal automatically', form)
if auto is not None:
    vo = idx(r'function verifyOtp\(', auto)
    endscript = idx(r'</script>', vo) if vo is not None else None
    if endscript is None:
        fail('old OTP script end not found')
    L[auto:endscript + 1] = ['']

# 6d. replace the old KYC modal block (from @if kyc_status==0 to the @endif right before the agreement block)
agr = idx(r'@if \(\$seller->agreement_accepted == 0\)')
end = None
for i in range(agr - 1, kyc, -1):
    if re.match(r'^\s*@endif\s*$', L[i]):
        end = i
        break
if end is None:
    fail('end of old KYC block not found')
L[kyc:end + 1] = ["                @include('sellerdashboard.partials.kyc', ['sxHideBanner' => true])"]

s = '\n'.join(L)

# 6e. onboarding card: agreement first, then KYC
old_steps = "['KYC details', ($seller->kyc_status ?? 0) == 1], ['Sign agreement', ($seller->agreement_accepted ?? 0) == 1]"
if old_steps in s:
    s = s.replace(old_steps, "['Sign agreement (Aadhaar)', ($seller->agreement_accepted ?? 0) == 1], ['KYC details', ($seller->kyc_status ?? 0) == 1]")
    report.append('onboarding steps reordered')
old_btn = re.search(r"@if \(\(\$seller->kyc_status \?\? 0\) == 0\)\s*\n(\s*<button[^\n]*#kycModal[^\n]*\n)\s*@else\s*\n(\s*<button[^\n]*#agreementModal[^\n]*\n)\s*@endif", s)
if old_btn:
    s = s[:old_btn.start()] + "@if (($seller->agreement_accepted ?? 0) == 0)\n" + old_btn.group(2) + "                @else\n" + old_btn.group(1) + "                @endif" + s[old_btn.end():]
    report.append('onboarding button order fixed')

# leftover old handlers that would clash
for pat in [r"\$\('#submitAgreement'\)", r"route\('aadhaar\.generate'\)", r"getElementById\('verifyOtpBtn'\)"]:
    if re.search(pat, s):
        report.append('WARNING leftover old code: ' + pat)

changes[p] = s

# ---------- write everything ----------
if os.environ.get('DRY'):
    print('\n'.join(report)); print('would update: ' + ', '.join(changes)); print('DRY OK'); sys.exit(0)
os.makedirs(BK, exist_ok=True)
for rel, content in changes.items():
    write(rel, content)
print('\n'.join(report))
print('BACKUP ' + BK)
print('PATCH OK')
